#ifndef BOTON_H
#define BOTON_H

// esto lo agregamos para GPIO
// general purpose input output
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "pico/time.h"


// Boton.h
// declaraciones de la clase Boton


// definir clase Boton
class Boton {

  // todo publico
  // nada de andar privatizando
  public:

  // atributos
  bool presionado = false;
  int duracionPresionado = 0;
  int patita;

  // aqui voy a agregar un temporizador
  // cosa que cada vez que el boton sea presionado
  // el LED se mantenga encendido por 
  // x cantidad de tiempo
  // para esto usare lo siguiente

  uint32_t momentoToque = 0;

  // ya con esto puedo agregar un atributo nuevo
  // que en este caso es el temporizador

  bool temporizadorActivo = false;

  // constructor
  Boton(int nuevaPatita);

  // metodos
  void leer();
  void presionar();
  void soltar();

  // este nuevo metodo va a hacer que 
  // "temporizadorActivo" sea true 
  // hasta que se cumpla el tiempo indicado

  bool temporizadorVigente(uint32_t duracionMs);

};

#endif