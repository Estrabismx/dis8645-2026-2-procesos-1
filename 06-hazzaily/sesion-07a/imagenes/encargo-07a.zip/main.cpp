// esto venia en wokwi
#include <stdio.h>
#include "pico/stdlib.h"

// incluir mis archivos
#include "Boton.h"

int main() {

  stdio_init_all();

  // para el segundo boton
  // quiero lograr que el LED
  // de la raspi se prenda 
  //al mantenerlo presionado

  // para esto
  // llamamos al LED integrado de la raspi

  const uint LED = PICO_DEFAULT_LED_PIN;
  gpio_init(LED);
  gpio_set_dir(LED, GPIO_OUT);

  // aqui encontramos los dos botones

  Boton miPrimerBoton(7);
  Boton botonLed(15);
  
  while (true) {

    // aqui voy a replicar la estructura

    miPrimerBoton.leer();
    botonLed.leer();

    if (miPrimerBoton.presionado) {
      printf("bacan estoy presionado, pero igual me presiona\n");
    }
    else {
      // cuando no este presionado
      printf("no hay nadie presionandome\n");
    }

  // y para el boton que controla el LED

  gpio_put(LED, botonLed.presionado);

    sleep_ms(100);

  }
}