// Boton.cpp
// implementaciones de la clase

// importar el archivo header
#include "Boton.h"

// constructor
Boton::Boton(int nuevaPatita) {

  // guardar el valor
  Boton::patita = nuevaPatita;

   // inicializar patita
  gpio_init(Boton::patita);
  // la patita es entrada
  gpio_set_dir(Boton::patita, GPIO_IN);

  // aqui voy a agregar esto
  // que lo que hace es que 
  // se active la resistencia interna de la raspi
  // asi no debemos de conectar una nueva
  // de forma externa

  gpio_pull_down(Boton::patita);
}

void Boton::leer() {

  // con esto guardamos el estado del boton
  // antes de leer el nuevo

  bool estabaPresionado = Boton::presionado;

    // leer boton
    Boton::presionado = gpio_get(Boton::patita);

  // ahora vamos a declarar que el boton
  // detecte el momento exacto del toque
  // asi que no importa si se mantiene presionado
  // contara el toque inicial para
  // mantener el LED encendido

  if (Boton::presionado && !estabaPresionado){

    // to_ms_since_boot convierte el reloj de la Pico a milisegundos
    // get_absolute_time() es "la hora actual" segun la raspi

  Boton::momentoToque = to_ms_since_boot(get_absolute_time());

  // y aqui se activa el temporizador

  Boton::temporizadorActivo = true;

  }

}

bool Boton::temporizadorVigente(uint32_t duracionMs) {

  // esto sucede cuando se presiona el boton
  // sino 
  // no hay nada que hacer

  if (!Boton::temporizadorActivo) {
    return false;
  }

  // especificamos que hora es ahora en ms

  uint32_t ahora = to_ms_since_boot(get_absolute_time());

  // aqui vemos el tiempo transcurrido desde el toque
  // y si ya paso la suracion pedida
  // se apaga

  if (ahora - Boton::momentoToque >= duracionMs) {
    Boton::temporizadorActivo = false;
    return false;
  }

  // y si todavia estamos dentro del tiempo

  return true;

}

// metodos
void Boton::presionar() {
  Boton::presionado = true;
  // queda pendiente calcular
  // cuanto rato lleva presionado
}
  
void Boton::soltar() {
   Boton::presionado = false;
   Boton::duracionPresionado = 0;
}